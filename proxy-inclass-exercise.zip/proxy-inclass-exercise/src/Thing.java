public interface Thing {
    void compute(String string);
}
